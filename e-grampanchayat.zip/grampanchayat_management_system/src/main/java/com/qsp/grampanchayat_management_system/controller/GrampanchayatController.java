package com.qsp.grampanchayat_management_system.controller;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PatchExchange;
import org.springframework.web.service.annotation.PutExchange;

import com.qsp.grampanchayat_management_system.dao.GrampanchayatDao;
import com.qsp.grampanchayat_management_system.dto.Admin;
import com.qsp.grampanchayat_management_system.dto.GPBody;
import com.qsp.grampanchayat_management_system.dto.Grampanchayat;
import com.qsp.grampanchayat_management_system.dto.Scheme;
import com.qsp.grampanchayat_management_system.dto.Villager;
import com.qsp.grampanchayat_management_system.service.GrampanchayatService;
import com.qsp.grampanchayat_management_system.util.ResponseStructure;

import jakarta.validation.Valid;

@RestController
public class GrampanchayatController {
	
	@Autowired
	private GrampanchayatService service;
	
	@PostMapping("/signup/admin")
	public ResponseEntity<ResponseStructure<Admin>> signUpAdmin(@Valid @RequestBody Admin admin) {
		return service.signUpAdmin(admin);
	}
	@GetMapping("/login")
	public ResponseEntity<ResponseStructure<Admin>> seaGrampanchayat(@RequestParam String email,@RequestParam String password) {
		return service.login(email,password);
	}

	@GetMapping("/find/grampanchayat/id")
	public ResponseEntity<ResponseStructure<Grampanchayat>> getGrampanchayatDetails(@RequestParam int id) {
		return service.getGrampanchayatDetails(id);
	}
	@PatchMapping("/update/grampanchayat")
	public ResponseEntity<ResponseStructure<Grampanchayat>> updateGrampanchayatDetails(@RequestParam int id,@RequestBody Grampanchayat grampanchayat){
		return service.updateGrampanchayatDetails(id, grampanchayat);
	}
	@GetMapping("/find/gpmembers")
	public ResponseEntity<ResponseStructure<List<GPBody>>> getGpMembers(@RequestParam int gpId) {
		return service.getGpMembers(gpId);
	}
	@GetMapping("/find/villagers")
	public ResponseEntity<ResponseStructure<List<Villager>>> getVillager(@RequestParam int gpId) {
		return service.getVillagesr(gpId);
	}
	@PatchMapping("/add/scheme")
	public ResponseEntity<ResponseStructure<List<Scheme>>>  addScheme(@RequestParam int id,@RequestBody Scheme scheme) {
		return service.addScheme(id, scheme);
	}
	@GetMapping("/find/villager/adhar")
	public ResponseEntity<ResponseStructure<Villager>> findVillager(@RequestParam long adharNo) {
		return service.findVillagerByAdhar(adharNo);
	}
	
	//villagers specifications
	@PostMapping("/signup/villager")
	public ResponseEntity<ResponseStructure<Villager>> signUpVillager(@RequestParam int gpId,@RequestBody Villager villager) {
		return service.signUpVillager(gpId, villager);
	}
	@PatchMapping("/apply/scheme")
	public ResponseEntity<ResponseStructure<Villager>>  addVillagerToExistingScheme(@RequestParam long villagerAdhar,@RequestParam int schemeId) {
		return service. applyScheme(villagerAdhar, schemeId);
	}
	@PatchMapping("/update/profile")
	public ResponseEntity<ResponseStructure<Villager>> updateProfile(@RequestParam long adharNo,@RequestBody Villager villager) {
		return service.updateProfile(adharNo,villager);
	}
}
