package com.qsp.grampanchayat_management_system.dao;

import java.util.ArrayList;
import java.util.List;


import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.sql.model.ast.builder.CollectionRowDeleteByUpdateSetNullBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.qsp.grampanchayat_management_system.dto.Admin;
import com.qsp.grampanchayat_management_system.dto.GPBody;
import com.qsp.grampanchayat_management_system.dto.Grampanchayat;
import com.qsp.grampanchayat_management_system.dto.Scheme;
import com.qsp.grampanchayat_management_system.dto.Villager;
import com.qsp.grampanchayat_management_system.exceptions.IdNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.SchemeAlreadyActivetedException;
import com.qsp.grampanchayat_management_system.exceptions.SchemeNotFoundException;
import com.qsp.grampanchayat_management_system.repository.GrampanchayatRepository;
import com.qsp.grampanchayat_management_system.service.GrampanchayatService;

@Repository
public class GrampanchayatDao {
	
	@Autowired
	private GrampanchayatRepository repository;
	
	
	public Admin signUpAdmin(Admin admin) {
		return repository.save(admin);
	}
	public Admin login(String email) {
		return	repository.findByAdminEmail(email);
	}
	public Grampanchayat getGrampanchayatDetatils(int id) {
		Grampanchayat grampanchayat=repository.findByGrampanchayatId(id);
		return grampanchayat!=null?grampanchayat:null;
	}
	public Grampanchayat updateGrampanchayatDetails(int id,Grampanchayat grampanchayat) {
		Grampanchayat dbGrampanchayat=repository.findByGrampanchayatId(id);
		if(dbGrampanchayat!=null) {
			grampanchayat.setGpId(id);
			grampanchayat.setDocuments(dbGrampanchayat.getDocuments());
			grampanchayat.setGpBody(dbGrampanchayat.getGpBody());
			grampanchayat.setSchemes(dbGrampanchayat.getSchemes());
			grampanchayat.setVillagers(dbGrampanchayat.getVillagers());
			
			return repository.save(grampanchayat);
		}
		return null;
	}
	public List<GPBody> findGpMembers(int gpId) {
		Grampanchayat grampanchayat=repository.findByGrampanchayatId(gpId);
		return grampanchayat!=null?grampanchayat.getGpBody():null;
	}
	public List<Villager> findVillagers(int gpId){
		Grampanchayat grampanchayat=repository.findByGrampanchayatId(gpId);
		return grampanchayat!=null?grampanchayat.getVillagers():null;
	}
	public Villager applyScheme(long adharNo,int schemeId) {
		Villager villager=repository.findByVillagerAdharNo(adharNo);
		Scheme schemes=repository.findBySchemeById(schemeId);
		if(villager!=null&&schemes!=null) {
			if(villager.getScheme().stream().filter((scheme)->scheme.getSchemeId()==schemeId).findFirst().isEmpty()) {
					villager.getScheme().add(schemes);
					return	repository.save(villager);
			}
			else {
				return villager;
			}
		}
		else {
			return null;
		}
	}
	public List<Scheme> addScheme(int gpId,Scheme scheme) {
		Grampanchayat grampanchayat=repository.findByGrampanchayatId(gpId);
		if(grampanchayat!=null) {
			if(grampanchayat.getSchemes().stream().filter((schemes)->schemes.getSchemeName().equals(scheme.getSchemeName())).findFirst().isEmpty()) {
				grampanchayat.getSchemes().add(scheme);
				return repository.save(grampanchayat).getSchemes();
			}
			return null;
		}
		return null;
	}
	public Villager findVillager(long adharNo) {
		Villager villager=repository.findByVillagerAdharNo(adharNo);
		return villager!=null?villager:null;
	}
	public Villager signUpVillager(int gpId,Villager villager) {
		Grampanchayat grampanchayat=repository.findByGrampanchayatId(gpId);
		if(grampanchayat!=null) {
		grampanchayat.getVillagers().add(villager);
		return repository.save(grampanchayat).getVillagers().stream().filter((villagers)->villagers.getVillagerAdharNo()==villager.getVillagerAdharNo()).findFirst().get();
		}
		else{
			return null;
		}
	}
	public Villager updateProfile(long adharNo,Villager villager) {
		Villager dbVillager=repository.findByVillagerAdharNo(adharNo);
		if(dbVillager!=null) {
			return repository.save(villager);
		}
		return null;
	}
}
