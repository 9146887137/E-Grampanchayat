package com.qsp.grampanchayat_management_system.dto;

import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
public class GPBody {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int memberId;
	@NotNull(message = "name cant be null")
	@NotBlank(message = "name cant be blank")
	private String memberName;
	private int memberAge;
	@Column(unique = true)
	@Min(value = 6000000000l)
	@Max(value = 9999999999l)
	private long memberPhone;
	@Column(unique = true)
	private long memberAdharNo;
	private String memberRole;

}
