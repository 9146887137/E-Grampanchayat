package com.qsp.grampanchayat_management_system.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
public class Grampanchayat {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int gpId;
	
	@NotNull(message = "name cant be null")
	@NotBlank(message = "name camnt be blank")
	private String gpName;
	@NotNull(message = "cant be null or blank")
	@NotBlank(message = "subdist camnt be blank")
	private String gpSubDist;
	@NotNull(message = "cant be null or blank")
	@NotBlank(message = "dist camnt be blank")
	private String gpDistrict;
	@NotNull(message = "cant be null or blank")
	@NotBlank(message = "state camnt be blank")
	private String gpState;
	private int popualation;
	private int gpMembers;
	@OneToMany(cascade = CascadeType.ALL)
	private List<GPBody> gpBody;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Scheme> schemes;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Villager> villagers;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Document> documents;

}
