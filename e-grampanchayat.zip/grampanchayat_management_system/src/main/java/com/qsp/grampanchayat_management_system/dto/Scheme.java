package com.qsp.grampanchayat_management_system.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.websocket.OnError;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Data
@Entity
public class Scheme {

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int schemeId;
	@NotNull(message = "name cant be null")
	@NotBlank(message = "name cant be blank")
	private String schemeName;
	private boolean forDrd;
	private boolean forOpen;
	private boolean forScSt;
	private double schemeAmount;

}
