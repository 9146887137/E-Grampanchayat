package com.qsp.grampanchayat_management_system.dto;



import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
@Entity
public class Villager {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int villagerId;
	private String villagerName;
	@Column(unique = true)
	private long villagerAdharNo;
	@Column(unique = true)
	private String voterId;
	private int homeNo;
	@Column(unique = true)
	@Min(value = 6000000000l)
	@Max(value = 9999999999l)
	private long villagerPhone;
	private String occupation;
	private String password;
	
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Scheme> scheme;
	

}
