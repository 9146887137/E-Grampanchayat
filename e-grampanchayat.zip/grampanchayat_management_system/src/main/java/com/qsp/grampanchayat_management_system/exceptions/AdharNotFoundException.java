package com.qsp.grampanchayat_management_system.exceptions;

public class AdharNotFoundException extends RuntimeException{

	public AdharNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public AdharNotFoundException(String message) {
		super(message);
	}
}
