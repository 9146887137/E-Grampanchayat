package com.qsp.grampanchayat_management_system.exceptions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.qsp.grampanchayat_management_system.util.ResponseStructure;

@RestControllerAdvice
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> handleIdNotFoundException(IdNotFoundException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("id not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(EmailNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> handleEmailNotFoundException(EmailNotFoundException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("email not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(UserAlreadyExistException.class)
	public ResponseEntity<ResponseStructure<String>> handleUserAlreadyExistException(UserAlreadyExistException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("user already exist");
		structure.setStatus(HttpStatus.BAD_REQUEST.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(NameNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> handleNameNotFoundException(NameNotFoundException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("name not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(SchemeNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> handleSchemeNotFoundException(SchemeNotFoundException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("scheme not found");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(AdharNotFoundException.class)
	public ResponseEntity<ResponseStructure<String>> handleAdharNotFoundException(AdharNotFoundException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("adhar not found.!");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(InvalidDataException.class)
	public ResponseEntity<ResponseStructure<String>> handleInvalidDataException(InvalidDataException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("invalid data provided!");
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(SchemeAlreadyActivetedException.class)
	public ResponseEntity<ResponseStructure<String>> handleSchemeAlreadyActivetedException(SchemeAlreadyActivetedException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("cant apply for scheme");
		structure.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_ACCEPTABLE);
	}
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<ResponseStructure<String>> handleDataIntegrityViolationException(DataIntegrityViolationException exception) {
		ResponseStructure<String> structure=new ResponseStructure<String>();
		structure.setMessage("villager already exist");
		structure.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
		structure.setData(exception.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.NOT_ACCEPTABLE);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		List<ObjectError> objectErrors=ex.getAllErrors();
		Map<String, String> map=new HashMap<String, String>();
		for(ObjectError error:objectErrors) {
			FieldError error2=(FieldError)error;
			String fiString=error2.getObjectName();
			String message="user already exist ! failed to add";
			map.put(fiString, message);
		}
		return new ResponseEntity<Object>(map,HttpStatus.BAD_REQUEST);
	}
	
}
