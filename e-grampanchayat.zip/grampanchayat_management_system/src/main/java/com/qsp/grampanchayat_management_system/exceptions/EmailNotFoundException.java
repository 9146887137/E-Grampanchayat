package com.qsp.grampanchayat_management_system.exceptions;

public class EmailNotFoundException extends RuntimeException{
	
	public EmailNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public EmailNotFoundException(String message) {
		super(message);
	}
	

}
