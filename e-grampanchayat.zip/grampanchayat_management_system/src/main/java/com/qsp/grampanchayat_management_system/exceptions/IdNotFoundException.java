package com.qsp.grampanchayat_management_system.exceptions;

public class IdNotFoundException extends RuntimeException{
	
	private IdNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public IdNotFoundException(String message) {
		super(message);
	}
}
