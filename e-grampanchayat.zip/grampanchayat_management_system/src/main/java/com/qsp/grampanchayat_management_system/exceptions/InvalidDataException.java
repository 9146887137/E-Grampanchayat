package com.qsp.grampanchayat_management_system.exceptions;

public class InvalidDataException extends RuntimeException{

	public InvalidDataException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidDataException(String message) {
		super(message);
	}
}
