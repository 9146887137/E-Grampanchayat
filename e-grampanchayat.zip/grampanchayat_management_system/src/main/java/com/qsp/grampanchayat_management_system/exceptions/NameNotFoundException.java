package com.qsp.grampanchayat_management_system.exceptions;

public class NameNotFoundException extends RuntimeException{
	
	private NameNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public NameNotFoundException(String  message) {
		super(message);
	}

}
