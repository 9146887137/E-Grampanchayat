package com.qsp.grampanchayat_management_system.exceptions;

public class NoSuchMemberException extends RuntimeException{

	public NoSuchMemberException() {
		// TODO Auto-generated constructor stub
	}
	public NoSuchMemberException(String message) {
		super(message);
	}
}
