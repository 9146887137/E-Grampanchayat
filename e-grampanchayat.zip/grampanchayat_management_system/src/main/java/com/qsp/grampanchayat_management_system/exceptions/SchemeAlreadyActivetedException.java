package com.qsp.grampanchayat_management_system.exceptions;

public class SchemeAlreadyActivetedException extends RuntimeException{

	
	public SchemeAlreadyActivetedException() {
		// TODO Auto-generated constructor stub
	}
	public SchemeAlreadyActivetedException(String message) {
		super(message);
	}
}
