package com.qsp.grampanchayat_management_system.exceptions;

public class SchemeNotFoundException extends RuntimeException{

	public SchemeNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public SchemeNotFoundException(String message) {
		super(message);
	}
}
