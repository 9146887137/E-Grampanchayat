package com.qsp.grampanchayat_management_system.exceptions;

public class UserAlreadyExistException extends RuntimeException{

	public UserAlreadyExistException() {
		// TODO Auto-generated constructor stub
	}
	public UserAlreadyExistException(String message) {
		super(message);
	}
}
