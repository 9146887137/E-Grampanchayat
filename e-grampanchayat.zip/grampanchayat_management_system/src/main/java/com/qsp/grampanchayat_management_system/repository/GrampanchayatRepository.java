package com.qsp.grampanchayat_management_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

import com.qsp.grampanchayat_management_system.dto.Admin;
import com.qsp.grampanchayat_management_system.dto.Grampanchayat;
import com.qsp.grampanchayat_management_system.dto.Scheme;
import com.qsp.grampanchayat_management_system.dto.Villager;

public interface GrampanchayatRepository extends JpaRepository<Admin, Integer>{
	
	Admin findByAdminEmail(String email);
	@Query("select gp FROM Grampanchayat gp WHERE gp.gpId=?1")
	Grampanchayat findByGrampanchayatId(int id);
	Grampanchayat save(Grampanchayat grampanchayat);
	Villager save(Villager villager);
	@Query("select v FROM Villager v WHERE v.villagerAdharNo=?1")
	Villager findByVillagerAdharNo(long villagerAdhar);
	@Query("select s FROM Scheme s WHERE s.schemeId=?1")
	Scheme findBySchemeById(int id);

}
