package com.qsp.grampanchayat_management_system.service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.text.html.ListView;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.grampanchayat_management_system.dao.GrampanchayatDao;
import com.qsp.grampanchayat_management_system.dto.Admin;
import com.qsp.grampanchayat_management_system.dto.GPBody;
import com.qsp.grampanchayat_management_system.dto.Grampanchayat;
import com.qsp.grampanchayat_management_system.dto.Scheme;
import com.qsp.grampanchayat_management_system.dto.Villager;
import com.qsp.grampanchayat_management_system.exceptions.AdharNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.EmailNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.IdNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.InvalidDataException;
import com.qsp.grampanchayat_management_system.exceptions.NameNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.NoSuchMemberException;
import com.qsp.grampanchayat_management_system.exceptions.SchemeAlreadyActivetedException;
import com.qsp.grampanchayat_management_system.exceptions.SchemeNotFoundException;
import com.qsp.grampanchayat_management_system.exceptions.UserAlreadyExistException;
import com.qsp.grampanchayat_management_system.repository.GrampanchayatRepository;
import com.qsp.grampanchayat_management_system.util.ResponseStructure;

@Service
public class GrampanchayatService {

	@Autowired
	private GrampanchayatDao dao;
	
	public ResponseEntity<ResponseStructure<Admin>> signUpAdmin(Admin admin) {
		Admin dbAdmin=dao.signUpAdmin(admin);
		ResponseStructure<Admin> structure=new ResponseStructure<Admin>();
		structure.setMessage("Admin Signup success..!");
		structure.setStatus(HttpStatus.CREATED.value());
		structure.setData(dbAdmin);
		return new ResponseEntity<ResponseStructure<Admin>>(structure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Admin>> login(String email,String password) {
		Admin admin=dao.login(email);
		ResponseStructure<Admin> structure=new ResponseStructure<Admin>();
		if(admin!=null) {
			if(admin.getPassword().equalsIgnoreCase(password)){
				structure.setMessage("login successfully!");
				structure.setStatus(HttpStatus.FOUND.value());
				structure.setData(admin);
				return new ResponseEntity<ResponseStructure<Admin>>(structure,HttpStatus.FOUND);
			}
			else {
				structure.setMessage("invalid passsword!");
				structure.setStatus(HttpStatus.UNAUTHORIZED.value());
				structure.setData(null);
				return new ResponseEntity<ResponseStructure<Admin>>(structure,HttpStatus.UNAUTHORIZED);
			}
		}
		else {
			throw new EmailNotFoundException("No user Exist with given Email");
		}
	}
	public ResponseEntity<ResponseStructure<Grampanchayat>> getGrampanchayatDetails(int id) {
		Grampanchayat grampanchayat=dao.getGrampanchayatDetatils(id);
		ResponseStructure<Grampanchayat> structure=new ResponseStructure<Grampanchayat>();
		if(grampanchayat!=null) {
			structure.setMessage("grampanchayat present with given id");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(grampanchayat);
			return new ResponseEntity<ResponseStructure<Grampanchayat>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new IdNotFoundException("Grampanchayat with given id is not present");
		}
	}
	public ResponseEntity<ResponseStructure<Grampanchayat>> updateGrampanchayatDetails(int id,Grampanchayat grampanchayat) {
		Grampanchayat dbGrampanchayat=dao.updateGrampanchayatDetails(id, grampanchayat);
		ResponseStructure<Grampanchayat> structure=new ResponseStructure<Grampanchayat>();
		if(dbGrampanchayat!=null) {
			structure.setMessage("Grampanchayat updated..!");
			structure.setStatus(HttpStatus.OK.value());
			structure.setData(grampanchayat);
			return new ResponseEntity<ResponseStructure<Grampanchayat>>(structure,HttpStatus.OK);
		}
		else {
			throw new IdNotFoundException("Grampanchayat with given id is not present");
		}
	}
	public ResponseEntity<ResponseStructure<List<GPBody>>> getGpMembers(int GpId){
		List<GPBody> members=dao.findGpMembers(GpId);
		ResponseStructure<List<GPBody>> structure=new ResponseStructure<List<GPBody>>();
		if(members!=null) {
			structure.setMessage("members fetched..!");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(members);		
			return new ResponseEntity<ResponseStructure<List<GPBody>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new IdNotFoundException("invalid grampanchayat id!");
		}
	}
	public ResponseEntity<ResponseStructure<List<Villager>>> getVillagesr(int GpId){
		List<Villager> villagers=dao.findVillagers(GpId);
		ResponseStructure<List<Villager>> structure=new ResponseStructure<List<Villager>>();
		if(villagers!=null) {
			structure.setMessage("villagers fetched..!");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(villagers);		
			return new ResponseEntity<ResponseStructure<List<Villager>>>(structure,HttpStatus.FOUND);
		}
		else {
			throw new IdNotFoundException("invalid grampanchayat id!");
		}
	}
	public ResponseEntity<ResponseStructure<Villager>>  applyScheme(long villagerAdhar,int schemeId) {
		Villager villager=(Villager)dao.applyScheme(villagerAdhar, schemeId);
		ResponseStructure<Villager> structure=new ResponseStructure<Villager>();
		if(villager!=null) {
			if(villager.getScheme().isEmpty()) {
				structure.setMessage("successfully applied for scheme..!");
				structure.setStatus(HttpStatus.OK.value());
				structure.setData(villager);		
				return new ResponseEntity<ResponseStructure<Villager>>(structure,HttpStatus.OK);
			}
			else if(villager.getScheme().stream().filter((scheme)->scheme.getSchemeId()==schemeId).findFirst().isPresent()) {
				throw new SchemeAlreadyActivetedException("your already applied for this scheme.");
			}
			else {
				structure.setMessage("successfully applied for scheme..!");
				structure.setStatus(HttpStatus.OK.value());
				structure.setData(villager);		
				return new ResponseEntity<ResponseStructure<Villager>>(structure,HttpStatus.OK);
			}
		}
		else {
			throw new InvalidDataException("Invalid data? please provide valid data");
		}
	}
	public ResponseEntity<ResponseStructure<List<Scheme>>> addScheme(int gpId,Scheme scheme) {
		List<Scheme> schemes=dao.addScheme(gpId, scheme);
		ResponseStructure<List<Scheme>> structure=new ResponseStructure<List<Scheme>>();
		//Optional<Scheme> sc=schemes.stream().filter((sch)->sch.getSchemeName().equals(scheme.getSchemeName())).findFirst();
		if(schemes!=null) {
			structure.setMessage("scheme added successfully!");
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setData(schemes);
			return new ResponseEntity<ResponseStructure<List<Scheme>>>(structure,HttpStatus.CREATED);
		}
		else {
			throw new SchemeAlreadyActivetedException("scheme already exist");
		}
	}
	public ResponseEntity<ResponseStructure<Villager>> findVillagerByAdhar(long adhar) {
		Villager villager=dao.findVillager(adhar);
		ResponseStructure<Villager> structure=new ResponseStructure<Villager>();
		if(villager!=null) {
			structure.setMessage("villagers fetched..!");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(villager);		
			return new ResponseEntity<ResponseStructure<Villager>>(structure,HttpStatus.FOUND);
		}
		throw new AdharNotFoundException("user not exist with given adhar");
	}
	public  ResponseEntity<ResponseStructure<Villager>> signUpVillager(int gpId,Villager villager){
		Villager villager2=dao.signUpVillager(gpId, villager);
		ResponseStructure<Villager> structure=new ResponseStructure<Villager>();
		if(villager2!=null) {
			structure.setMessage("villagers fetched..!");
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setData(villager);		
			return new ResponseEntity<ResponseStructure<Villager>>(structure,HttpStatus.CREATED);
		}
		else {
			throw new UserAlreadyExistException("user already exist !you cant add");
		}
	}
	public ResponseEntity<ResponseStructure<Villager>> updateProfile(long adharNo,Villager villager) {
		Villager dbVillager=dao.updateProfile(adharNo,villager);
		ResponseStructure<Villager> structure=new ResponseStructure<Villager>();
		if(villager!=null) {
			structure.setMessage("profile update successfully..!");
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setData(dbVillager);		
			return new ResponseEntity<ResponseStructure<Villager>>(structure,HttpStatus.CREATED);
		}
		else {
			throw new AdharNotFoundException("invalid adhar number!please give correct adhar");
		}
	}
}
