package com.qsp.grampanchayat_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrampanchayatManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
